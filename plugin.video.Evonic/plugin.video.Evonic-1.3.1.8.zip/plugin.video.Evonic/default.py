# Evonic plugin written by Mentality
# -*- coding: utf-8 -*-
import re,os,urllib,urllib2
import xbmcplugin,xbmcgui
import xbmcaddon
import evonic as enter
from BeautifulSoup import BeautifulSoup as BS

__settings__ = xbmcaddon.Addon(id="plugin.video.Evonic")
status = __settings__.getSetting("status")

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param

params=get_params()
method=None
url=None
url0=None
name=None
mode=None
iconimage=None
imdb=None
plot=None
mpaa=None
trailer=None
serien_name=None
imdb_id=None
tvdb_id=None
season=None

try:
        method = urllib.unquote_plus(params["method"])
except:
        pass
try:
        url=urllib.unquote_plus(params['url'])
except:
        pass
try:
        url0=urllib.unquote_plus(params['url0'])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        iconimage=''
try:
        imdb=urllib.unquote_plus(params["imdb"])
except:
        imdb=''
try:
        plot=urllib.unquote_plus(params["plot"])
except:
        plot=''
try:
        mpaa=urllib.unquote_plus(params["mpaa"])
except:
        mpaa=''
try:
        serien_name=urllib.unquote_plus(params["serien_name"])
except:
        serien_name=''
try:
        season=urllib.unquote_plus(params["season"])
except:
        season=''
try:
        episode=urllib.unquote_plus(params["episode"])
except:
        episode=''
try:
        tvdb_id=str(params["tvdb_id"])
except:
        pass
try:
        imdb_id=str(params["imdb_id"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if method == None:
    enter.INDEX_GENRE("http://evonic.tv/forum/content.php")
else:
    #~ print "DEFAULT : "+tvdb_id
    exec "enter."+str(method)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
